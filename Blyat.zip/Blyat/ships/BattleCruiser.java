package spaceinv.ships;

public class BattleCruiser extends EnemyShip {

    public BattleCruiser(double x, double y, double width, double height, double dx, double dy) {
        super(x, y, width, height, dx, dy);
    }
}
