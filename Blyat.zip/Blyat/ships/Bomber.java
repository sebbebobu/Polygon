package spaceinv.ships;

public class Bomber extends EnemyShip {
    public Bomber(double x, double y, double width, double height, double dx, double dy) {
        super(x, y, width, height, dx, dy);
    }
}
