package spaceinv.test;

public class TestShip  {
    public TestShip(){
        //super(0,150,40,108,0,0);
    }
}