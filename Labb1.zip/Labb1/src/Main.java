import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args){
        List<Bil> biles = new ArrayList<>();
        biles.add(new Volvo240());
        biles.add(new Volvo240());
        biles.add(new Volvo240());
        biles.add(new Volvo240());
        biles.add(new Saab95());
        biles.add(new Saab95());
        biles.add(new Saab95());
        biles.add(new Saab95());
        for (Bil b : biles) {
            b.stopEngine();
            b.startEngine();
            b.getCurrentSpeed();
            b.getColor();
            b.getNrDoors();
            b.getEnginePower();
            b.move();
            b.turnLeft();
            b.turnRight();
            b.setColor(Color.BLUE);
            b.turnRight();
            b.move();
            b.turnRight();
            b.move();
            b.turnRight();
            b.move();
            b.turnRight();
            b.move();
            b.turnLeft();
            b.move();
            b.turnLeft();
            b.move();
            b.turnLeft();
            b.move();
            b.turnLeft();
            if (b instanceof Saab95){
                ((Saab95) b).gas(0);
                ((Saab95) b).brake(0);
                ((Saab95) b).setTurboOff();
                ((Saab95) b).setTurboOn();
                ((Saab95) b).speedFactor();
            }
            else if (b instanceof Volvo240){
                ((Volvo240) b).brake(0);
                ((Volvo240) b).gas(0);
            }
        }
    }
}