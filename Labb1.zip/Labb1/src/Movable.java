/**
 * Created by brandts on 2018-01-22.
 */
public interface Movable {
    void move();
    void turnLeft();
    void turnRight();
}
