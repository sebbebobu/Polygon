# Labb-1-2
Del 2 av Labb 1.
