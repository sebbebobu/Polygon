import java.awt.*;
public abstract class Polygon{
    protected int x, y;
    private Polygon(Point point) {
        this.x = point.x;
        this.y = point.y;
    }
    public Polygon(int x, int y) {
        this(new Point(x,y));
    }
    public void paint(Graphics g){
        throw new IllegalArgumentException("Can't draw abstract polygon!");
    }
}
