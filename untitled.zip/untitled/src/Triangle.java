import java.awt.*;

public class Triangle extends Polygon{
    public Triangle(int x, int y) {
        super(x,y);
    }

    @Override
    public void paint(Graphics g) {
        g.drawLine(x, y-10, x-10, y+10);
        g.drawLine(x-10, y+10, x+10, y+10);
        g.drawLine(x+10, y+10, x, y-10);
    }
}
